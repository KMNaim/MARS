function initWidget() {
  const text = document.body.innerText;

  // 🎯 Only show if "Look Back" exists
  if (!/Look Back/i.test(text)) return;

  const hasMS = /Firm\s*Number\s*:\s*MS/i.test(text);

  const today = new Date();
  const pastDate = new Date();
  pastDate.setDate(today.getDate() - 90);

  let contentHTML = "";

  if (hasMS) {
    contentHTML = `<div class="ms">⚠ MS running</div>`;
  } else {
    contentHTML = `
      <div><strong>📅 Today:</strong> ${today.toLocaleDateString()}</div>
      <div><strong>⏪ 90 Days Ago:</strong> ${pastDate.toLocaleDateString()}</div>
    `;
  }

  createWidget(contentHTML);
}

function createWidget(content) {
  let widget = document.getElementById("date-helper-widget");
  if (widget) return;

  widget = document.createElement("div");
  widget.id = "date-helper-widget";

  // saved theme or default
  const theme = localStorage.getItem("dh_theme") || "theme1";
  widget.className = theme;

  widget.innerHTML = `
    <div class="header">
      <span>📌 Date Helper</span>
      <div>
        <select id="themeSelector">
          <option value="theme1">Blue</option>
          <option value="theme2">Green</option>
          <option value="theme3">Purple</option>
          <option value="theme4">Dark</option>
        </select>
        <button id="closeWidget">✖</button>
      </div>
    </div>
    <div class="content">${content}</div>
  `;

  document.body.appendChild(widget);

  applyStyles();
  restorePosition(widget);
  makeDraggable(widget);

  // ❌ close button
  document.getElementById("closeWidget").onclick = () => widget.remove();

  // 🎨 theme selector
  const selector = document.getElementById("themeSelector");
  selector.value = theme;
  selector.onchange = () => {
    const selected = selector.value;
    widget.className = selected;
    localStorage.setItem("dh_theme", selected);
  };
}

function applyStyles() {
  const style = document.createElement("style");
  style.innerHTML = `
    #date-helper-widget {
      position: fixed;
      top: 100px;
      right: 20px;
      width: 240px;
      border-radius: 12px;
      font-family: Segoe UI, sans-serif;
      font-size: 13px;
      z-index: 9999;
      cursor: move;
      user-select: none;
      box-shadow: 0 8px 25px rgba(0,0,0,0.3);
      overflow: hidden;
    }

    /* Multiple Themes */
    #date-helper-widget.theme1 { background: linear-gradient(135deg, #1e3c72, #2a5298); color:#fff; }
    #date-helper-widget.theme2 { background: linear-gradient(135deg, #11998e, #38ef7d); color:#fff; }
    #date-helper-widget.theme3 { background: linear-gradient(135deg, #8e2de2, #4a00e0); color:#fff; }
    #date-helper-widget.theme4 { background: rgba(30,30,30,0.9); color:#fff; backdrop-filter: blur(8px); }

    .header {
      display: flex;
      justify-content: space-between;
      padding: 8px 10px;
      font-weight: bold;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }

    .header button {
      background: none;
      border: none;
      color: inherit;
      cursor: pointer;
      margin-left: 5px;
    }

    .header select {
      font-size: 12px;
      border-radius: 4px;
      border: none;
      padding: 2px 4px;
      margin-right: 5px;
      cursor: pointer;
    }

    .content { padding: 10px; line-height: 1.5; }

    .ms { color: #ff4d4f; font-weight:bold; background: rgba(255,0,0,0.1); padding: 5px; border-radius: 6px; }
  `;
  document.head.appendChild(style);
}

// 🖱 draggable + save position
function makeDraggable(el) {
  let isDragging = false, offsetX, offsetY;

  el.addEventListener("mousedown", (e) => {
    isDragging = true;
    offsetX = e.clientX - el.offsetLeft;
    offsetY = e.clientY - el.offsetTop;
  });

  document.addEventListener("mousemove", (e) => {
    if (isDragging) {
      el.style.left = e.clientX - offsetX + "px";
      el.style.top = e.clientY - offsetY + "px";
      el.style.right = "auto";

      localStorage.setItem("dh_pos", JSON.stringify({ left: el.style.left, top: el.style.top }));
    }
  });

  document.addEventListener("mouseup", () => { isDragging = false; });
}

// 📌 restore position
function restorePosition(el) {
  const pos = JSON.parse(localStorage.getItem("dh_pos"));
  if (pos) {
    el.style.left = pos.left;
    el.style.top = pos.top;
    el.style.right = "auto";
  }
}

window.addEventListener("load", initWidget);