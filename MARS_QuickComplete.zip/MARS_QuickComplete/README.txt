MARS Quick Complete - install (Chrome or Edge)

1. Open chrome://extensions  (Edge: edge://extensions)
2. Turn on "Developer mode"
3. Click "Load unpacked" and choose this MARS_QuickComplete folder
4. Reload the MARS page

Use:
  click a reason code (FINE, CANT, GEOG ...)  ->  Space = Complete  ->  Space = OK

Settings (content.js, top of file):
  AUTO_CONFIRM = true   clicks OK by itself, so one Space finishes the record.

After editing content.js, press the reload icon on the extension card, then reload MARS.
