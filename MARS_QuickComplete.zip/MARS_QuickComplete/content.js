// MARS Quick Complete (Double Press Space or Enter)
(() => {
  // Set to true to click OK automatically after Complete
  const AUTO_CONFIRM = false;

  const REASON_CODES = new Set([
    "CANT", "GEOG", "DOB", "DEF", "DEAD", "DUPE", "PROB", "FINE", "NAME", "LOC",
    "GEND", "IMAT", "JAIL", "NMIS", "NRSK", "RISK", "WHIT"
  ]);

  // Keys allowed to trigger actions
  const TRIGGER_KEYS = new Set(["Space", "Enter"]);
  const DOUBLE_PRESS_MS = 350; // Maximum time (ms) between two presses

  let armed = false;
  let swallowKeyup = false;
  let lastKeyPressTime = 0;
  let lastKeyCode = "";

  // ---------- helpers ----------
  const labelOf = el => ((el.value !== undefined && typeof el.value === "string" && el.tagName === "INPUT")
    ? el.value : (el.innerText || el.textContent || "")).trim();

  const isVisible = el => !!el && el.getClientRects().length > 0 &&
    getComputedStyle(el).visibility !== "hidden";

  function allDocs(doc = document, out = []) {
    out.push(doc);
    for (const f of doc.querySelectorAll("iframe, frame")) {
      try { if (f.contentDocument) allDocs(f.contentDocument, out); } catch (_) { /* cross-origin */ }
    }
    return out;
  }

  function findClickable(text, scope) {
    const target = text.toLowerCase();
    const docs = scope ? [scope] : allDocs();

    for (const root of docs) {
      const btns = root.querySelectorAll("button, input[type=button], input[type=submit], a");
      for (const b of btns) {
        if (labelOf(b).toLowerCase() === target && isVisible(b)) return b;
      }
    }
    for (const root of docs) {
      for (const el of root.querySelectorAll("span, div, td, em")) {
        if (labelOf(el).toLowerCase() !== target || !isVisible(el)) continue;
        const childMatch = [...el.children].some(c => labelOf(c).toLowerCase() === target);
        if (!childMatch) return el;
      }
    }
    return null;
  }

  function findConfirmDialog() {
    const dialogTitles = [
      "inquiry match completion",
      "complete information",
      "confirmation",
      "information"
    ];

    for (const root of allDocs()) {
      for (const el of root.querySelectorAll("div, table, td, span, h1, h2, h3, h4")) {
        const text = labelOf(el).toLowerCase();
        if (!dialogTitles.includes(text) || !isVisible(el)) continue;

        let box = el;
        for (let i = 0; i < 10 && box; i++, box = box.parentElement) {
          const ok = findClickable("OK", box) || findClickable("Confirm", box);
          if (ok) return ok;
        }
      }
    }

    for (const root of allDocs()) {
      const modal = root.querySelector('[role="dialog"], [role="alertdialog"], .modal, .popup, .ui-dialog');
      if (modal && isVisible(modal)) {
        const ok = findClickable("OK", modal) || findClickable("Confirm", modal);
        if (ok) return ok;
      }
    }

    return findClickable("OK");
  }

  function realClick(el) {
    const opts = { bubbles: true, cancelable: true, view: el.ownerDocument.defaultView };
    el.dispatchEvent(new MouseEvent("mousedown", opts));
    el.dispatchEvent(new MouseEvent("mouseup", opts));
    el.click();
  }

  function isTyping(el) {
    if (!el) return false;
    if (el.isContentEditable) return true;
    if (el.tagName === "TEXTAREA" || el.tagName === "SELECT") return true;
    if (el.tagName === "INPUT") {
      const t = (el.type || "text").toLowerCase();
      return !["button", "submit", "checkbox", "radio", "reset", "image"].includes(t);
    }
    return false;
  }

  let toastEl, toastTimer;
  function toast(msg, color = "#1f6feb") {
    if (!toastEl) {
      toastEl = document.createElement("div");
      toastEl.style.cssText = "position:fixed;top:10px;right:10px;z-index:2147483647;" +
        "padding:8px 14px;border-radius:6px;color:#fff;font:600 13px Segoe UI,Arial,sans-serif;" +
        "box-shadow:0 2px 8px rgba(0,0,0,.3);pointer-events:none;transition:opacity .2s";
      document.documentElement.appendChild(toastEl);
    }
    toastEl.textContent = msg;
    toastEl.style.background = color;
    toastEl.style.opacity = "1";
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toastEl.style.opacity = "0"; }, 1800);
  }

  function waitForConfirmThenClick(timeoutMs = 4000) {
    const start = Date.now();
    const tick = () => {
      const ok = findConfirmDialog();
      if (ok) { 
        realClick(ok); 
        toast("OK clicked", "#2da44e"); 
        return; 
      }
      if (Date.now() - start < timeoutMs) setTimeout(tick, 100);
    };
    tick();
  }

  // ---------- reason code clicks ----------
  document.addEventListener("click", e => {
    let el = e.target;
    for (let i = 0; i < 3 && el && el !== document.body; i++, el = el.parentElement) {
      const code = labelOf(el);
      if (REASON_CODES.has(code)) {
        armed = true;
        toast(`${code} selected - double-press to Complete`);
        return;
      }
    }
  }, true);

  // ---------- double keydown listener ----------
  window.addEventListener("keydown", e => {
    if (!TRIGGER_KEYS.has(e.code) || e.ctrlKey || e.altKey || e.metaKey || e.shiftKey || e.repeat) return;
    if (isTyping(e.target)) return;

    const now = Date.now();
    const isDoublePress = (e.code === lastKeyCode) && (now - lastKeyPressTime <= DOUBLE_PRESS_MS);

    lastKeyPressTime = now;
    lastKeyCode = e.code;

    if (!isDoublePress) return;

    // Reset tracking once double-press is acknowledged
    lastKeyPressTime = 0;
    lastKeyCode = "";

    // 1. Popup check
    const ok = findConfirmDialog();
    if (ok) {
      e.preventDefault(); 
      e.stopPropagation(); 
      swallowKeyup = true;
      realClick(ok);
      toast("OK clicked", "#2da44e");
      return;
    }

    // 2. Complete check
    const complete = findClickable("Complete");
    if (!complete) return;

    e.preventDefault(); 
    e.stopPropagation(); 
    swallowKeyup = true;
    if (!armed) { 
      toast("Pick a reason code first", "#cf222e"); 
      return; 
    }

    armed = false;
    realClick(complete);
    toast("Complete clicked - double-press again for OK", "#2da44e");
    
    if (AUTO_CONFIRM) waitForConfirmThenClick();
  }, true);

  // Stop focused buttons/inputs from triggering on key release
  window.addEventListener("keyup", e => {
    if (TRIGGER_KEYS.has(e.code) && swallowKeyup) {
      e.preventDefault(); 
      e.stopPropagation(); 
      swallowKeyup = false;
    }
  }, true);
})();