console.log("Address Helper script loaded successfully.");

document.addEventListener('keydown', function(event) {
  if (event.shiftKey && event.key.toLowerCase() === 'w') {
    togglePopup();
  }
});

function togglePopup() {
  let existingPopup = document.getElementById('tps-extension-popup');
  if (existingPopup) {
    existingPopup.remove();
    return;
  }

  // --- Dynamic Address Extraction ---
  let street = "", city = "", state = "", zip = "", country = "";
  const labels = document.querySelectorAll('.address-label');
  const values = document.querySelectorAll('.address-value');
  const pageText = document.body.innerText;

  if (labels.length > 0 && values.length > 0) {
    for (let i = 0; i < labels.length; i++) {
      let labelText = labels[i].innerText.toLowerCase();
      let valText = values[i] ? values[i].innerText.trim() : "";
      if (labelText.includes("address")) street = valText;
      else if (labelText.includes("city")) city = valText;
      else if (labelText.includes("province") || labelText.includes("state")) state = valText;
      else if (labelText.includes("postal") || labelText.includes("zip")) zip = valText;
      else if (labelText.includes("country")) country = valText;
    }
  } else {
    const streetMatch = pageText.match(/Address 1:\s*(?:Address 1:\s*)?(.*?)\s*(City 1:|Province 1:|Postal 1:|Country 1:|\n|$)/i);
    const cityMatch = pageText.match(/City 1:\s*(.*?)\s*(Province 1:|Postal 1:|Country 1:|\n|$)/i);
    const stateMatch = pageText.match(/Province 1:\s*(.*?)\s*(Postal 1:|Country 1:|\n|$)/i);
    const zipMatch = pageText.match(/Postal 1:\s*(.*?)\s*(Country 1:|\n|$)/i);
    const countryMatch = pageText.match(/Country 1:\s*(.*?)\s*(?:\n|$)/i);

    if (streetMatch) street = streetMatch[1].trim();
    if (cityMatch) city = cityMatch[1].trim();
    if (stateMatch) state = stateMatch[1].trim();
    if (zipMatch) zip = zipMatch[1].trim();
    if (countryMatch) country = countryMatch[1].trim();
  }

  if (!street && !city && !state && !zip) {
    alert("Address fields not found on this page.");
    return;
  }

  // --- Extract Inquiry Name ---
  let inquiryName = "";
  const nameMatch = pageText.match(/Inquiry Name:\s*(.*?)\s*Date of Birth:/i);
  if (nameMatch && nameMatch[1]) {
    inquiryName = nameMatch[1].trim();
  }

  // --- TruePeopleSearch Logic ---
  const tpsBaseUrl = "https://www.truepeoplesearch.com/resultaddress?streetaddress=";
  const streetEncoded = encodeURIComponent(street);
  let tpsCityStateStr = city;
  if (city && state) tpsCityStateStr = `${city}, ${state}`;
  else if (state) tpsCityStateStr = state;
  const tpsCityStateUrl = `${tpsBaseUrl}${streetEncoded}&citystatezip=${encodeURIComponent(tpsCityStateStr)}`;
  const tpsZipUrl = `${tpsBaseUrl}${streetEncoded}&citystatezip=${encodeURIComponent(zip)}`;

  // --- FastPeopleSearch & Whitepages Formatting Logic ---
  const formatHyphens = (str) => str.replace(/\s+/g, '-').toLowerCase();
  
  const formattedStreet = formatHyphens(street);
  let formattedCityState = formatHyphens(city);
  if (city && state) formattedCityState += '-' + formatHyphens(state);
  else if (state) formattedCityState = formatHyphens(state);
  
  const fpsCityStateUrl = `https://www.fastpeoplesearch.com/address/${formattedStreet}_${formattedCityState}`;
  const fpsZipUrl = `https://www.fastpeoplesearch.com/address/${formattedStreet}_${zip}`;

  // Whitepages URL structure
  const wpCityStateUrl = `https://www.whitepages.com/address/${formattedStreet}/${formattedCityState}`;

  // --- Google Search Logic ---
  const firstAddressString = [inquiryName, street].filter(Boolean).join(", ");
  const googleFirstAddressUrl = `https://www.google.com/search?q=${encodeURIComponent(firstAddressString)}`;

  const quotedStreet = street ? `"${street}"` : "";
  const firstAddressQuotedString = [inquiryName, quotedStreet].filter(Boolean).join(" ");
  const googleFirstAddressQuotedUrl = `https://www.google.com/search?q=${encodeURIComponent(firstAddressQuotedString)}`;

  const fullAddressString = [inquiryName, street, city, state, zip, country].filter(Boolean).join(", ");
  const googleFullAddressUrl = `https://www.google.com/search?q=${encodeURIComponent(fullAddressString)}`;

  // --- UI Creation ---
  const popup = document.createElement('div');
  popup.id = 'tps-extension-popup';

  const createBtn = (text, onClick, customClass = '') => {
    const btn = document.createElement('button');
    btn.innerText = text;
    btn.onclick = onClick;
    if (customClass) btn.classList.add(customClass);
    return btn;
  };

  const createTitle = (text) => {
    const title = document.createElement('div');
    title.innerText = text;
    title.className = 'section-title';
    return title;
  };

  popup.appendChild(createTitle('TruePeopleSearch'));
  popup.appendChild(createBtn('Copy City/State Link', () => copyToClipboard(tpsCityStateUrl)));
  popup.appendChild(createBtn('Copy Zip Code Link', () => copyToClipboard(tpsZipUrl)));

  popup.appendChild(createTitle('FastPeopleSearch'));
  popup.appendChild(createBtn('Copy City/State Link', () => copyToClipboard(fpsCityStateUrl), 'fps-btn'));
  popup.appendChild(createBtn('Copy Zip Code Link', () => copyToClipboard(fpsZipUrl), 'fps-btn'));

  popup.appendChild(createTitle('Whitepages'));
  popup.appendChild(createBtn('Open City/State Link', () => {
    chrome.runtime.sendMessage({ action: "openIncognito", url: wpCityStateUrl });
}, 'wp-btn'));
  popup.appendChild(createBtn('Copy City/State Link', () => copyToClipboard(wpCityStateUrl), 'wp-btn'));

  popup.appendChild(createTitle('Google Search'));
  popup.appendChild(createBtn('Search Name & 1st Address', () => window.open(googleFirstAddressUrl, '_blank'), 'google-btn'));
  popup.appendChild(createBtn('Search Name & "1st Address"', () => window.open(googleFirstAddressQuotedUrl, '_blank'), 'google-btn'));
  popup.appendChild(createBtn('Search Name & Full Address', () => window.open(googleFullAddressUrl, '_blank'), 'google-btn'));

  popup.appendChild(createBtn('Close', togglePopup, 'close-btn'));

  document.body.appendChild(popup);
}

function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    alert('Link copied to clipboard!');
  }).catch(err => {
    console.error('Failed to copy: ', err);
  });
}