// background.js
// Listens for messages from the content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "openIncognito") {
        // Opens a new incognito window with the requested URL
        chrome.windows.create({
            url: request.url,
            incognito: true
        });
    }
});