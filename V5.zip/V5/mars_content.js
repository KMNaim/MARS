// ==========================================
// CONFIGURATION SYSTEM
// ==========================================
let config = {
    delay: 0.10, 
    shortcut_single_geog: true,
    shortcut_single_risk: true,
    shortcut_single_nmis: true,
    shortcut_single_dob: true,
    shortcut_single_def: true,
    shortcut_bulk_geog: true,
    shortcut_bulk_risk: true,
    shortcut_bulk_nmis: true,
    shortcut_bulk_dob: true,
    shortcut_bulk_imat: true,
    shortcut_special_nrsk: true,
    shortcut_special_complete: true,
    shortcut_auto_escalate: true
};

chrome.storage.sync.get(config, (items) => { config = items; });

chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync') {
        for (let [key, { newValue }] of Object.entries(changes)) {
            config[key] = newValue;
        }
    }
});


// ==========================================
// PART 1: MARS GRID MATCH VALIDATOR LOGIC
// ==========================================
const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
        if (mutation.addedNodes.length && document.body.innerText.includes("Inquiry Match Completion")) {
            validateGridMatches();
        }
    }
});
observer.observe(document.body, { childList: true, subtree: true });

function validateGridMatches() {
    if (window.validatorHasRun) return;
    const pageText = document.body.innerText;
    
    const gridMatch = pageText.match(/Total GRID Match Count[:\s]+(\d+)/i);
    const alertsMatch = pageText.match(/Total Alerts[:\s]+(\d+)/i);
    const noMatchMatch = pageText.match(/Total No Match[:\s]+(\d+)/i);

    if (gridMatch && alertsMatch && noMatchMatch) {
        const totalGrid = parseInt(gridMatch[1], 10);
        const totalAlerts = parseInt(alertsMatch[1], 10);
        const totalNoMatch = parseInt(noMatchMatch[1], 10);

        if (totalGrid !== (totalAlerts + totalNoMatch)) {
            alert(`MARS VALIDATION WARNING!\n\nMath does not add up:\nTotal GRID Match Count: ${totalGrid}\nTotal Alerts: ${totalAlerts}\nTotal No Match: ${totalNoMatch}`);
        }
        window.validatorHasRun = true;
        setTimeout(() => { window.validatorHasRun = false; }, 5000);
    }
}


// ==========================================
// PART 2: MARS CLICKER & SELECTOR LOGIC
// ==========================================
function forceClick(element) {
    element.click();
    const mouseClick = new MouseEvent('click', { bubbles: true, cancelable: true, view: window });
    element.dispatchEvent(mouseClick);
}

function getCustomDelayMs() {
    return (config.delay || 0.10) * 1000; 
}

function checkOnceAndClick(selector, delayMs = getCustomDelayMs()) {
    setTimeout(function() {
        const element = document.querySelector(selector);
        if (element && element.offsetParent !== null) {
            forceClick(element);
        }
    }, delayMs); 
}

function smartSingleClick(mainSelector, popupSelector) {
    const popup = document.querySelector(popupSelector);
    
    if (popup && popup.offsetParent !== null) {
        forceClick(popup);
        return true; 
    }

    const mainElement = document.querySelector(mainSelector);
    if (mainElement && mainElement.offsetParent !== null) {
        forceClick(mainElement);
        checkOnceAndClick(popupSelector, 200); 
        return true;
    }
    
    return false;
}

function bulkSelectRadios(actionText) {
    const targetRadios = [];
    document.querySelectorAll('td').forEach(td => {
        const radios = td.querySelectorAll('input[type="radio"]');
        if (radios.length === 2 && td.innerText.trim().includes(actionText)) {
            targetRadios.push(radios[1]);
        }
    });
    if (targetRadios.length === 0) return;

    targetRadios.forEach(function(radio, index) {
        setTimeout(function() { forceClick(radio); }, index * 10);
    });
}

function bulkClickWithConfirmation(mainSelector, confirmSelector) {
    const allButtons = document.querySelectorAll(mainSelector);
    const visibleButtons = Array.from(allButtons).filter(button => button.offsetParent !== null);
    if (visibleButtons.length === 0) return false;

    const delayMs = getCustomDelayMs();
    visibleButtons.forEach(function(button, index) {
        setTimeout(function() {
            forceClick(button);
            checkOnceAndClick(confirmSelector, delayMs);
        }, index * delayMs); 
    });
    return true; 
}

// --- Single Logic Handlers ---
function handleGeogOrName() {
    if (!smartSingleClick('.status-reason-button.status-reason-button-GEOG', '.ev-status-reason-button.status-reason-button-GEOG')) {
        smartSingleClick('.status-reason-button.status-reason-button-NAME', '.ev-status-reason-button.status-reason-button-NAME');
    }
}
function handleRisk() { smartSingleClick('.status-reason-button.status-reason-button-RISK', '.ev-status-reason-button.status-reason-button-RISK'); }
function handleNmis() { smartSingleClick('.status-reason-button.status-reason-button-NMIS', '.ev-status-reason-button.status-reason-button-NMIS'); }
function handleDob() { smartSingleClick('.status-reason-button.status-reason-button-DOB', '.ev-status-reason-button.status-reason-button-DOB'); }
function handleDef() { smartSingleClick('.status-reason-button.status-reason-button-DEF', '.ev-status-reason-button.status-reason-button-DEF'); }

function handleNrskSequential() {
    bulkSelectRadios("No Match");
    bulkClickWithConfirmation('.status-reason-button.status-reason-button-NRSK', '.ev-status-reason-button.status-reason-button-NRSK');
}
function handleComplete() {
    const completeBtn = document.querySelector('#show_complete_confirm');
    if (completeBtn) forceClick(completeBtn);
}

// --- Bulk Logic Handlers ---
function handleBulkGeogOrName() {
    if (!bulkClickWithConfirmation('.status-reason-button.status-reason-button-GEOG', '.ev-status-reason-button.status-reason-button-GEOG')) {
        bulkClickWithConfirmation('.status-reason-button.status-reason-button-NAME', '.ev-status-reason-button.status-reason-button-NAME');
    }
}
function handleBulkRisk() { bulkClickWithConfirmation('.status-reason-button.status-reason-button-RISK', '.ev-status-reason-button.status-reason-button-RISK'); }
function handleBulkNmis() { bulkClickWithConfirmation('.status-reason-button.status-reason-button-NMIS', '.ev-status-reason-button.status-reason-button-NMIS'); }
function handleBulkDob() { bulkClickWithConfirmation('.status-reason-button.status-reason-button-DOB', '.ev-status-reason-button.status-reason-button-DOB'); }
function handleBulkImat() { bulkClickWithConfirmation('.status-reason-button.status-reason-button-IMAT', '.ev-status-reason-button.status-reason-button-IMAT'); }

// --- Text Insertion Handler ---
function handleAutoEscalate() {
    const activeElement = document.activeElement;
    const phrase = "Auto Escalate";
    
    // Check if the user is currently focused on a text input or textarea
    if (activeElement && (activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA')) {
        const start = activeElement.selectionStart;
        const end = activeElement.selectionEnd;
        const text = activeElement.value;
        
        // Insert the phrase exactly where the cursor is
        activeElement.value = text.substring(0, start) + phrase + text.substring(end);
        
        // Move the cursor to the end of the newly inserted text
        activeElement.selectionStart = activeElement.selectionEnd = start + phrase.length;
        
        // Trigger standard browser events so the web page registers the new text
        activeElement.dispatchEvent(new Event('input', { bubbles: true }));
        activeElement.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
        // Fallback: If no text box is focused, copy it to the clipboard
        navigator.clipboard.writeText(phrase).then(() => {
            console.log("Copied 'Auto Escalate' to clipboard.");
        });
    }
}

// ==========================================
// PART 3: EVENT LISTENER WITH CONFIG CHECKS
// ==========================================
window.addEventListener('keydown', function(event) {
    const isSpacebar = (event.code === 'Space' || event.key === ' ');
    const isKeyS = (event.code === 'KeyS' || event.key === 's' || event.key === 'S');
    const isKeyZ = (event.code === 'KeyZ' || event.key === 'z' || event.key === 'Z'); 
    const isKeyX = (event.code === 'KeyX' || event.key === 'x' || event.key === 'X'); 
    const isKeyC = (event.code === 'KeyC' || event.key === 'c' || event.key === 'C');
    const isKeyA = (event.code === 'KeyA' || event.key === 'a' || event.key === 'A');
    
    const isNumpadPlus = (event.code === 'NumpadAdd');
    const isNumpadMinus = (event.code === 'NumpadSubtract');
    const isNumpadDecimal = (event.code === 'NumpadDecimal'); 
    const isNumpadMultiply = (event.code === 'NumpadMultiply');

    // === SINGLE CLICKS ===
    if (event.ctrlKey && !event.shiftKey && !event.altKey && isSpacebar) {
        if (!config.shortcut_single_geog) return;
        event.preventDefault(); handleGeogOrName(); 
    }
    if (!event.ctrlKey && event.shiftKey && !event.altKey && isKeyZ) {
        if (!config.shortcut_single_risk) return;
        event.preventDefault(); handleRisk(); 
    }
    if (!event.ctrlKey && event.shiftKey && !event.altKey && isKeyX) {
        if (!config.shortcut_single_nmis) return;
        event.preventDefault(); handleNmis();
    }
    if (!event.ctrlKey && event.shiftKey && !event.altKey && isKeyS) {
        if (!config.shortcut_single_dob) return;
        event.preventDefault(); handleDob();
    }
    if (!event.ctrlKey && !event.shiftKey && !event.altKey && isNumpadPlus) {
        if (!config.shortcut_single_def) return;
        event.preventDefault(); handleDef();
    }

    // === BULK CLICKS ===
    if (!event.ctrlKey && !event.shiftKey && event.altKey && isKeyC) {
        if (!config.shortcut_bulk_geog) return;
        event.preventDefault(); handleBulkGeogOrName();
    }
    if (!event.ctrlKey && !event.shiftKey && event.altKey && isKeyZ) {
        if (!config.shortcut_bulk_risk) return;
        event.preventDefault(); handleBulkRisk();
    }
    if (!event.ctrlKey && !event.shiftKey && event.altKey && isKeyX) {
        if (!config.shortcut_bulk_nmis) return;
        event.preventDefault(); handleBulkNmis();
    }
    if (!event.ctrlKey && !event.shiftKey && event.altKey && isKeyS) {
        if (!config.shortcut_bulk_dob) return;
        event.preventDefault(); handleBulkDob();
    }
    if (!event.ctrlKey && !event.shiftKey && !event.altKey && isNumpadMultiply) {
        if (!config.shortcut_bulk_imat) return;
        event.preventDefault(); handleBulkImat();
    }

    // === SPECIAL SHORTCUTS ===
    const isShiftC = (!event.ctrlKey && event.shiftKey && !event.altKey && isKeyC);
    const isJustNumpadMinus = (!event.ctrlKey && !event.shiftKey && !event.altKey && isNumpadMinus);
    if (isShiftC || isJustNumpadMinus) {
        if (!config.shortcut_special_nrsk) return;
        event.preventDefault(); handleNrskSequential(); 
    }

    const isShiftSpace = (!event.ctrlKey && event.shiftKey && !event.altKey && isSpacebar);
    const isJustNumpadDecimal = (!event.ctrlKey && !event.shiftKey && !event.altKey && isNumpadDecimal);
    if (isShiftSpace || isJustNumpadDecimal) {
        if (!config.shortcut_special_complete) return;
        event.preventDefault(); handleComplete();
    }
    
    // Auto Escalate Text Insertion
    if (!event.ctrlKey && event.shiftKey && !event.altKey && isKeyA) {
        if (!config.shortcut_auto_escalate) return;
        event.preventDefault(); 
        handleAutoEscalate(); 
    }
});