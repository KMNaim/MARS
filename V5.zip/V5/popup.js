// Default settings
const defaultSettings = {
    delay: 0.10,
    shortcut_single_geog: true,
    shortcut_single_risk: true,
    shortcut_single_nmis: true,
    shortcut_single_dob: true,
    shortcut_single_def: true,
    shortcut_bulk_geog: true,
    shortcut_bulk_risk: true,
    shortcut_bulk_nmis: true,
    shortcut_bulk_dob: true,
    shortcut_bulk_imat: true,
    shortcut_special_nrsk: true,
    shortcut_special_complete: true,
    shortcut_auto_escalate: true
};

// Save options to chrome.storage
function saveOptions() {
    const settings = {
        delay: parseFloat(document.getElementById('delay').value),
        shortcut_single_geog: document.getElementById('shortcut_single_geog').checked,
        shortcut_single_risk: document.getElementById('shortcut_single_risk').checked,
        shortcut_single_nmis: document.getElementById('shortcut_single_nmis').checked,
        shortcut_single_dob: document.getElementById('shortcut_single_dob').checked,
        shortcut_single_def: document.getElementById('shortcut_single_def').checked,
        shortcut_bulk_geog: document.getElementById('shortcut_bulk_geog').checked,
        shortcut_bulk_risk: document.getElementById('shortcut_bulk_risk').checked,
        shortcut_bulk_nmis: document.getElementById('shortcut_bulk_nmis').checked,
        shortcut_bulk_dob: document.getElementById('shortcut_bulk_dob').checked,
        shortcut_bulk_imat: document.getElementById('shortcut_bulk_imat').checked,
        shortcut_special_nrsk: document.getElementById('shortcut_special_nrsk').checked,
        shortcut_special_complete: document.getElementById('shortcut_special_complete').checked,
        shortcut_auto_escalate: document.getElementById('shortcut_auto_escalate').checked
    };

    chrome.storage.sync.set(settings, () => {
        const status = document.getElementById('status');
        status.textContent = 'Settings saved!';
        setTimeout(() => { status.textContent = ''; }, 1500);
    });
}

// Restore options from chrome.storage
function restoreOptions() {
    chrome.storage.sync.get(defaultSettings, (items) => {
        document.getElementById('delay').value = items.delay;
        document.getElementById('shortcut_single_geog').checked = items.shortcut_single_geog;
        document.getElementById('shortcut_single_risk').checked = items.shortcut_single_risk;
        document.getElementById('shortcut_single_nmis').checked = items.shortcut_single_nmis;
        document.getElementById('shortcut_single_dob').checked = items.shortcut_single_dob;
        document.getElementById('shortcut_single_def').checked = items.shortcut_single_def;
        document.getElementById('shortcut_bulk_geog').checked = items.shortcut_bulk_geog;
        document.getElementById('shortcut_bulk_risk').checked = items.shortcut_bulk_risk;
        document.getElementById('shortcut_bulk_nmis').checked = items.shortcut_bulk_nmis;
        document.getElementById('shortcut_bulk_dob').checked = items.shortcut_bulk_dob;
        document.getElementById('shortcut_bulk_imat').checked = items.shortcut_bulk_imat;
        document.getElementById('shortcut_special_nrsk').checked = items.shortcut_special_nrsk;
        document.getElementById('shortcut_special_complete').checked = items.shortcut_special_complete;
        document.getElementById('shortcut_auto_escalate').checked = items.shortcut_auto_escalate;
    });
}

// Add event listeners
document.addEventListener('DOMContentLoaded', restoreOptions);

// Auto-save when an input changes
const inputs = document.querySelectorAll('input');
inputs.forEach(input => {
    input.addEventListener('change', saveOptions);
});