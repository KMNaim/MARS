// GitHub Raw Direct Links
const RULES_URL = "https://raw.githubusercontent.com/sabbirrahmanleon/MARS-Notifier-Database/main/alert_rules.json";
const NOTES_URL = "https://raw.githubusercontent.com/sabbirrahmanleon/MARS-Notifier-Database/main/grid_info.json";

function setupAlarm() {
    chrome.storage.local.get(['autoSyncRulesEnabled', 'autoSyncNotesEnabled'], (data) => {
        if (data.autoSyncRulesEnabled !== false || data.autoSyncNotesEnabled !== false) { 
            console.log("Setting up 2-minute auto-sync alarm.");
            chrome.alarms.create("marsAutoSync", { periodInMinutes: 2 });
        } else {
            console.log("Both auto-syncs disabled. Clearing alarm.");
            chrome.alarms.clear("marsAutoSync");
        }
    });
}

chrome.runtime.onInstalled.addListener(() => {
    console.log("MARS Notifier installed.");
    setupAlarm();
});

chrome.runtime.onStartup.addListener(() => {
    performAutoSync();
    setupAlarm();
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "marsAutoSync") {
        performAutoSync();
    }
});

chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local' && (changes.autoSyncRulesEnabled || changes.autoSyncNotesEnabled)) {
        setupAlarm();
        performAutoSync(); 
    }
});

async function performAutoSync() {
    chrome.storage.local.get(['autoSyncRulesEnabled', 'autoSyncNotesEnabled', 'rules', 'notes'], async (data) => {
        let rulesUpdated = false;
        let notesUpdated = false;
        let uniqueRules = data.rules || [];
        let uniqueNotes = data.notes || [];

        // SYNC RULES
        if (data.autoSyncRulesEnabled !== false) {
            try {
                const response = await fetch(RULES_URL, { cache: "no-store" });
                const cloudRules = await response.json();
                const unlockedRules = cloudRules.map(r => ({ ...r, isTeam: false, active: true }));
                
                const combinedRules = [...uniqueRules, ...unlockedRules];
                uniqueRules = [];
                const seenRules = new Set();
                combinedRules.forEach(r => {
                    if (!r) return;
                    const identifier = (r.keyword || "").trim() + '|' + (r.message || "").trim();
                    if (!seenRules.has(identifier)) { seenRules.add(identifier); uniqueRules.push(r); }
                });
                rulesUpdated = true;
            } catch (e) { console.error("Rules Auto-sync failed."); }
        }

        // SYNC INFO
        if (data.autoSyncNotesEnabled !== false) {
            try {
                const response = await fetch(NOTES_URL, { cache: "no-store" });
                const cloudNotes = await response.json();
                
                const combinedNotes = [...uniqueNotes, ...cloudNotes];
                uniqueNotes = [];
                const seenNotes = new Set();
                combinedNotes.forEach(n => {
                    if (!n || !n.gridId) return;
                    const identifier = (n.gridId || "").trim() + '|' + (n.info || "").trim();
                    if (!seenNotes.has(identifier)) { seenNotes.add(identifier); uniqueNotes.push(n); }
                });
                notesUpdated = true;
            } catch (e) { console.error("Related Info Auto-sync failed."); }
        }

        if (rulesUpdated || notesUpdated) {
            chrome.storage.local.set({ rules: uniqueRules, notes: uniqueNotes });
        }
    });
}