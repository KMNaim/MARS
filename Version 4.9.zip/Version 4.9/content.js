let dismissedRules = new Set();
let scanTimeout = null;
let globalDisable = false; // Tracks the Shift+D toggle state

// Initialize global disable state from memory
chrome.storage.local.get(['globalDisable', 'rules', 'notes'], (data) => {
    globalDisable = data.globalDisable || false;
    
    // Only kick off the live page scanners after the real disable state is loaded
    if (document.body) {
        observer.observe(document.body, { childList: true, subtree: true, characterData: true });
        if (!globalDisable) {
            executeScan();
        }
    }
});

// Listen for the Shift+D toggle changing across tabs
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local' && changes.globalDisable !== undefined) {
        globalDisable = changes.globalDisable.newValue;
        if (globalDisable) {
            removeAllPopups();
        } else {
            executeScan();
        }
    }
});

// --- KEYBOARD SHORTCUTS ---
document.addEventListener('keydown', (e) => {
    // SHIFT + Q: Dismiss all current popups (Replaces Shift + S)
    if (e.shiftKey && e.key.toLowerCase() === 'q') {
        e.preventDefault(); 
        removeAllPopups();
    }

    // SHIFT + D: Toggle all popups on/off globally
    if (e.shiftKey && e.key.toLowerCase() === 'd') {
        e.preventDefault();
        chrome.storage.local.get(['globalDisable'], (data) => {
            const newState = !data.globalDisable;
            chrome.storage.local.set({ globalDisable: newState }, () => {
                alert(`MARS Notifier: Popups are now ${newState ? 'DISABLED (Muted)' : 'ENABLED (Active)'}`);
            });
        });
    }
});

// Helper to wipe screen clean
function removeAllPopups() {
    document.querySelectorAll('[id^="nrsk-alert-"]').forEach(el => {
        const idx = el.id.replace('nrsk-alert-', '');
        dismissedRules.add(parseInt(idx));
        el.remove();
    });
    
    document.querySelectorAll('[id^="nrsk-note-"]').forEach(el => {
        const idx = el.id.replace('nrsk-note-', '');
        dismissedRules.add('note-' + idx);
        el.remove();
    });
    
    clearHighlights();
    
    document.querySelectorAll('[id^="alert-container-"]').forEach(container => {
        checkMinification(container.id);
    });
}

function getPositionContainer(pos) {
    const safePos = pos || 'bottom-left';
    let containerId = `alert-container-${safePos}`;
    let container = document.getElementById(containerId);
    
    if (!container) {
        container = document.createElement('div');
        container.id = containerId;
        const [vert, horiz] = safePos.split('-');
        
        Object.assign(container.style, {
            position: 'fixed', zIndex: '2147483647', display: 'flex', flexDirection: 'column',
            gap: '10px', pointerEvents: 'none', width: 'max-content', padding: '20px'
        });

        if (vert === 'top') container.style.top = '0';
        else if (vert === 'middle') { container.style.top = '56.5%'; container.style.transform = 'translateY(-50%)'; } 
        else container.style.bottom = '0';

        if (horiz === 'left') container.style.left = '0';
        else if (horiz === 'center') { container.style.left = '50%'; container.style.transform += ' translateX(-50%)'; container.style.alignItems = 'center'; } 
        else { container.style.right = '0'; container.style.alignItems = 'flex-end'; }

        let toggleBtn = document.createElement('div');
        toggleBtn.id = containerId + '-toggle';
        Object.assign(toggleBtn.style, {
            display: 'none', background: '#333', color: '#fff', padding: '12px 20px',
            borderRadius: '8px', cursor: 'pointer', fontWeight: 'bold', fontSize: '14px',
            pointerEvents: 'auto', boxShadow: '0 4px 15px rgba(0,0,0,0.4)',
            textAlign: 'center', border: '2px solid #555', fontFamily: 'Arial, sans-serif',
            letterSpacing: '0.5px'
        });
        
        let listContainer = document.createElement('div');
        listContainer.id = containerId + '-list';
        Object.assign(listContainer.style, {
            display: 'flex', flexDirection: 'column', gap: '10px'
        });

        toggleBtn.onclick = () => {
            if (listContainer.style.display === 'none') {
                listContainer.style.display = 'flex';
                toggleBtn.innerText = 'Collapse Alerts [ - ]';
            } else {
                listContainer.style.display = 'none';
                toggleBtn.innerText = listContainer.children.length + ' Alerts Detected [ + ]';
            }
        };

        if (vert === 'bottom') {
            container.appendChild(listContainer);
            container.appendChild(toggleBtn);
        } else {
            container.appendChild(toggleBtn);
            container.appendChild(listContainer);
        }

        document.body.appendChild(container);
    }
    return container;
}

function checkMinification(containerId) {
    let listContainer = document.getElementById(containerId + '-list');
    let toggleBtn = document.getElementById(containerId + '-toggle');
    if (!listContainer || !toggleBtn) return;
    
    let count = listContainer.children.length;
    if (count > 3) {
        if (toggleBtn.style.display === 'none') {
            toggleBtn.style.display = 'block';
            listContainer.style.display = 'none';
            toggleBtn.innerText = count + ' Alerts Detected [ + ]';
        } else if (listContainer.style.display === 'none') {
            toggleBtn.innerText = count + ' Alerts Detected [ + ]';
        }
    } else {
        toggleBtn.style.display = 'none';
        listContainer.style.display = 'flex';
    }
}

// --- HIGHLIGHT ENGINE ---
function clearHighlights() {
    document.querySelectorAll('.mars-highlight').forEach(el => {
        const parent = el.parentNode;
        parent.replaceChild(document.createTextNode(el.textContent), el);
        parent.normalize(); 
    });
    document.querySelectorAll('.mars-img-highlight').forEach(img => {
        img.style.outline = "";
        img.classList.remove('mars-img-highlight');
    });
    document.querySelectorAll('.mars-bg-highlight').forEach(el => {
        el.style.backgroundColor = "";
        el.style.color = "";
        el.classList.remove('mars-bg-highlight');
    });
}

function highlightText(searchText, isExact) {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    let node;
    const nodesToHighlight = [];
    
    while (node = walker.nextNode()) {
        const parent = node.parentNode;
        if (parent && (parent.tagName === 'SCRIPT' || parent.tagName === 'STYLE' || parent.closest('[id^="alert-container"]'))) continue;
        
        if (isExact) {
            let exactWord = searchText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            let regex = new RegExp(`(^|[^a-zA-Z0-9_:,.-])${exactWord}([^a-zA-Z0-9_:,.-]|$)`, 'i');
            if (regex.test(node.nodeValue)) {
                nodesToHighlight.push(node);
            }
        } else {
            if (node.nodeValue.toUpperCase().includes(searchText.toUpperCase())) {
                nodesToHighlight.push(node);
            }
        }
    }

    if (nodesToHighlight.length === 0) return false;

    nodesToHighlight.forEach(n => {
        const regex = new RegExp(`(${searchText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
        const fragment = document.createDocumentFragment();
        let lastIdx = 0;
        let matchFound = false;
        
        n.nodeValue.replace(regex, (match, p1, offset) => {
            matchFound = true;
            const before = document.createTextNode(n.nodeValue.slice(lastIdx, offset));
            const mark = document.createElement('mark');
            mark.style.backgroundColor = "#fbc02d";
            mark.style.color = "#000";
            mark.style.borderRadius = "2px";
            mark.style.boxShadow = "0 0 3px rgba(0,0,0,0.3)";
            mark.textContent = match;
            mark.className = "mars-highlight";
            fragment.appendChild(before);
            fragment.appendChild(mark);
            lastIdx = offset + match.length;
        });
        
        if (matchFound) {
            const after = document.createTextNode(n.nodeValue.slice(lastIdx));
            fragment.appendChild(after);
            if (n.parentNode) n.parentNode.replaceChild(fragment, n);
        }
    });
    return true;
}

function applyHighlightToDOM(kw) {
    let cleanKw = kw.trim();
    if (!cleanKw) return;

    if (cleanKw.toLowerCase().startsWith('class:')) {
        const partialClass = cleanKw.slice(6).trim();
        document.querySelectorAll(`[class*="${partialClass}"]`).forEach(el => {
            el.style.outline = "4px solid #fbc02d";
            el.classList.add('mars-img-highlight');
        });
        return;
    }
    if (cleanKw.toLowerCase().startsWith('img:')) {
        const imgSrc = cleanKw.slice(4).trim();
        document.querySelectorAll(`img[src*="${imgSrc}"]`).forEach(img => {
            img.style.outline = "4px solid #fbc02d";
            img.classList.add('mars-img-highlight');
        });
        return;
    }
    if (cleanKw.toLowerCase().startsWith('r-icon-')) {
        const cleanClass = cleanKw.replace(/[^a-zA-Z0-9_-]/g, '');
        document.querySelectorAll('.' + cleanClass).forEach(el => {
            el.style.outline = "4px solid #fbc02d";
            el.classList.add('mars-img-highlight');
        });
        return;
    }
    if (cleanKw.toLowerCase().startsWith('badge:')) {
        const badgeText = cleanKw.slice(6).trim().toUpperCase();
        document.querySelectorAll('td hm, td .hltd_text, .entity-event-info hm').forEach(el => {
            if ((el.textContent || "").trim().toUpperCase() === badgeText) {
                el.style.backgroundColor = "#fbc02d";
                el.style.color = "#000";
                el.classList.add('mars-bg-highlight');
            }
        });
        return;
    }
    if (cleanKw.toLowerCase().startsWith('strike:')) {
        const strikeText = cleanKw.slice(7).trim().toUpperCase();
        document.querySelectorAll('span, td, tr, div, p, a, b, strong').forEach(el => {
            const elText = (el.textContent || "").trim().toUpperCase();
            if (elText.length > 0 && (strikeText === "ANY" || strikeText === "" || elText.includes(strikeText))) {
                const style = window.getComputedStyle(el);
                if (style.textDecoration.includes('line-through') || style.textDecorationLine.includes('line-through')) {
                    el.style.backgroundColor = "#fbc02d";
                    el.style.color = "#000";
                    el.classList.add('mars-bg-highlight');
                }
            }
        });
        return;
    }

    let isExact = cleanKw.startsWith('"') && cleanKw.endsWith('"');
    let searchText = isExact ? cleanKw.slice(1, -1) : cleanKw;
    if (!searchText) return;

    let found = highlightText(searchText, isExact);

    if (!found) {
        let words = searchText.split(/[\s/|.,-]+/).filter(w => w.trim().length > 1);
        if (words.length > 1) {
            words.forEach(word => highlightText(word, false));
        }
    }
}

function triggerHighlight(triggerString) {
    clearHighlights();
    const groups = triggerString.split(',').map(k => k.trim()).filter(k => k.length > 0);
    groups.forEach(group => {
        const conditions = group.split('+').map(c => c.trim()).filter(c => c.length > 0);
        conditions.forEach(cond => {
            applyHighlightToDOM(cond); 
        });
    });

    setTimeout(() => {
        const firstMark = document.querySelector('mark.mars-highlight, .mars-img-highlight, .mars-bg-highlight');
        if (firstMark) firstMark.scrollIntoView({behavior: "smooth", block: "center"});
    }, 50);
}

// --- CORE SCANNER ---
function executeScan() {
    // HALT SCANNING IF SHIFT+D TOGGLE IS ACTIVE
    if (globalDisable) return;

    chrome.storage.local.get(['rules', 'notes'], (data) => {
        const rules = data.rules || [];
        const notes = data.notes || [];
        
        let rawText = document.body ? document.body.innerText : "";
        
        try {
            const alertContainers = document.querySelectorAll('[id^="alert-container"]');
            for (let container of alertContainers) {
                const alertText = container.innerText;
                if (alertText) { rawText = rawText.replace(alertText, " "); }
            }
        } catch (e) {}

        try {
            const allElements = document.querySelectorAll('*');
            for (let el of allElements) {
                if (el.children.length === 0 && el.textContent.trim() === 'Instructions') {
                    let container = el.closest('td');
                    if (!container) container = el.parentElement.parentElement;
                    if (container && container !== document.body && container.tagName !== 'HTML') {
                        const sidebarText = container.innerText;
                        if (sidebarText) { rawText = rawText.replace(sidebarText, " "); }
                        break;
                    }
                }
            }
        } catch (e) {}
        
        const pageText = rawText.replace(/\s+/g, ' ');

        rules.forEach((rule, index) => {
            const popupId = `nrsk-alert-${index}`;
            const containerId = `alert-container-${rule.position || 'bottom-left'}`;

            if (!rule || !rule.keyword || rule.active === false) {
                const existing = document.getElementById(popupId);
                if (existing) {
                    existing.remove();
                    checkMinification(containerId);
                }
                dismissedRules.delete(index);
                return;
            }

            const isMatchFound = (kw) => {
                let cleanKw = kw.trim();
                
                if (cleanKw.toLowerCase().startsWith('class:')) {
                    const partialClass = cleanKw.slice(6).trim();
                    return document.querySelector(`[class*="${partialClass}"]`) !== null;
                }
                if (cleanKw.toLowerCase().startsWith('img:')) {
                    const imgSrc = cleanKw.slice(4).trim();
                    return document.querySelector(`img[src*="${imgSrc}"]`) !== null;
                }
                if (cleanKw.toLowerCase().startsWith('r-icon-')) {
                    const cleanClass = cleanKw.replace(/[^a-zA-Z0-9_-]/g, '');
                    return document.querySelector('.' + cleanClass) !== null;
                }
                if (cleanKw.toLowerCase().startsWith('badge:')) {
                    const badgeText = cleanKw.slice(6).trim().toUpperCase();
                    const badges = Array.from(document.querySelectorAll('td hm, td .hltd_text, .entity-event-info hm'));
                    return badges.some(b => (b.textContent || "").trim().toUpperCase() === badgeText);
                }
                if (cleanKw.toLowerCase().startsWith('strike:')) {
                    const strikeText = cleanKw.slice(7).trim().toUpperCase();
                    const elementsToCheck = document.querySelectorAll('span, td, tr, div, p, a, b, strong');
                    for (let el of elementsToCheck) {
                        const elText = (el.textContent || "").trim().toUpperCase();
                        if (elText.length === 0) continue;
                        if (strikeText !== "ANY" && strikeText !== "" && !elText.includes(strikeText)) continue;
                        const style = window.getComputedStyle(el);
                        if (style.textDecoration.includes('line-through') || style.textDecorationLine.includes('line-through')) return true;
                    }
                    return false;
                }
                
                if (cleanKw.startsWith('"') && cleanKw.endsWith('"')) {
                    let exactWord = cleanKw.slice(1, -1).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                    let regex = new RegExp(`(^|[^a-zA-Z0-9_:,.-])${exactWord}([^a-zA-Z0-9_:,.-]|$)`, 'i');
                    return regex.test(pageText); 
                } else {
                    let flatKw = cleanKw.replace(/\s+/g, ' ');
                    return pageText.toUpperCase().includes(flatKw.toUpperCase());
                }
            };

            const keywordGroups = rule.keyword.split(',').map(k => k.trim()).filter(k => k.length > 0);
            let hasMatch = keywordGroups.some(group => {
                const conditions = group.split('+').map(c => c.trim()).filter(c => c.length > 0);
                return conditions.length > 0 && conditions.every(isMatchFound);
            });
            
            let hasException = false;
            if (rule.exception) {
                const exceptionGroups = rule.exception.split(',').map(k => k.trim()).filter(k => k.length > 0);
                hasException = exceptionGroups.some(group => {
                    const conditions = group.split('+').map(c => c.trim()).filter(c => c.length > 0);
                    return conditions.length > 0 && conditions.every(isMatchFound);
                });
            }
            
            if (hasMatch && !hasException) {
                if (!dismissedRules.has(index)) showPopup(rule, index);
            } else {
                const existing = document.getElementById(popupId);
                if (existing) {
                    existing.remove();
                    checkMinification(containerId);
                }
                dismissedRules.delete(index);
            }
        });

        notes.forEach((note, index) => {
            const notePopupId = `nrsk-note-${index}`;
            const containerId = `alert-container-bottom-left`;

            if (!note || !note.gridId) return;

            const gridIds = note.gridId.split(',').map(id => id.trim()).filter(id => id.length > 0);
            let hasMatch = false;
            let matchedId = ""; 

            for (let gId of gridIds) {
                let exactWord = gId.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                let regex = new RegExp(`(^|[^a-zA-Z0-9_:,.-])${exactWord}([^a-zA-Z0-9_:,.-]|$)`, 'i');
                if (regex.test(pageText) || pageText.toUpperCase().includes(gId.toUpperCase())) {
                    hasMatch = true;
                    matchedId = gId; 
                    break; 
                }
            }
            
            if (hasMatch) {
                if (!dismissedRules.has('note-' + index)) {
                    const displayNote = { ...note, gridId: matchedId };
                    showNotePopup(displayNote, index);
                }
            } else {
                const existing = document.getElementById(notePopupId);
                if (existing) {
                    existing.remove();
                    checkMinification(containerId);
                }
                dismissedRules.delete('note-' + index);
            }
        });
    });
}

function showPopup(rule, index) {
    const popupId = `nrsk-alert-${index}`;
    if (document.getElementById(popupId)) return;
    
    const containerId = `alert-container-${rule.position || 'bottom-left'}`;
    getPositionContainer(rule.position || 'bottom-left');
    const listContainer = document.getElementById(containerId + '-list');

    const alertBox = document.createElement('div');
    alertBox.id = popupId;
    Object.assign(alertBox.style, { width: '240px', padding: '15px', borderRadius: '10px', border: '3px solid white', backgroundColor: rule.color || '#b71c1c', color: 'white', display: 'flex', flexDirection: 'column', fontFamily: 'Arial, sans-serif', boxShadow: '0 10px 25px rgba(0,0,0,0.5)', pointerEvents: 'auto' });
    
    const headerRow = document.createElement('div');
    Object.assign(headerRow.style, { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' });
    
    const titleSpan = document.createElement('span');
    titleSpan.innerHTML = `<strong>CAUTION!!!</strong>`;
    Object.assign(titleSpan.style, { fontSize: '16px', lineHeight: '1' });
    
    const buttonGroup = document.createElement('div');
    Object.assign(buttonGroup.style, { display: 'flex', gap: '5px', alignItems: 'center' });
    
    const hlBtn = document.createElement('button');
    hlBtn.innerText = 'FIND';
    Object.assign(hlBtn.style, { cursor: 'pointer', background: 'rgba(255,255,255,0.2)', border: '1px solid rgba(255,255,255,0.4)', color: 'inherit', fontSize: '9px', fontWeight: 'bold', borderRadius: '3px', padding: '4px 5px', letterSpacing: '0.5px' });
    hlBtn.onclick = () => triggerHighlight(rule.keyword);

    const closeBtn = document.createElement('button');
    closeBtn.innerText = '×';
    Object.assign(closeBtn.style, { cursor: 'pointer', background: 'rgba(255,255,255,0.2)', border: 'none', color: 'inherit', fontSize: '18px', fontWeight: 'bold', borderRadius: '4px', padding: '0 6px', lineHeight: '1' });
    closeBtn.onclick = () => { 
        dismissedRules.add(index); 
        alertBox.remove(); 
        clearHighlights(); 
        checkMinification(containerId);
    };
    
    buttonGroup.appendChild(hlBtn);
    buttonGroup.appendChild(closeBtn);
    
    headerRow.appendChild(titleSpan);
    headerRow.appendChild(buttonGroup);

    const bodyRow = document.createElement('div');
    bodyRow.innerHTML = `<span style="font-size:${rule.fontSize || '14px'}; line-height:1.2; overflow-wrap: break-word; display: block;">${rule.message}</span>`;
    
    alertBox.appendChild(headerRow);
    alertBox.appendChild(bodyRow);
    
    listContainer.appendChild(alertBox);
    checkMinification(containerId);
}

const observer = new MutationObserver((mutations) => {
    let shouldScan = false;
    for (let m of mutations) {
        if (m.target && m.target.id && typeof m.target.id === 'string' && m.target.id.includes('alert-container')) continue;
        if (m.target && m.target.closest && m.target.closest('[id^="alert-container"]')) continue;
        shouldScan = true; 
        break;
    }
    if (shouldScan) {
        clearTimeout(scanTimeout);
        scanTimeout = setTimeout(executeScan, 800); 
    }
});

function showNotePopup(note, index) {
    const popupId = `nrsk-note-${index}`;
    if (document.getElementById(popupId)) return;
    
    const containerId = 'alert-container-bottom-left';
    getPositionContainer('bottom-left'); 
    const listContainer = document.getElementById(containerId + '-list');

    const alertBox = document.createElement('div');
    alertBox.id = popupId;
    Object.assign(alertBox.style, { width: '240px', padding: '15px', borderRadius: '0px 10px 10px 10px', border: '1px solid #fbc02d', borderLeft: '5px solid #f57f17', backgroundColor: '#fff9c4', color: '#000', display: 'flex', flexDirection: 'column', fontFamily: 'Arial, sans-serif', boxShadow: '0 5px 15px rgba(0,0,0,0.2)', pointerEvents: 'auto' });
    
    const headerRow = document.createElement('div');
    Object.assign(headerRow.style, { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' });
    
    const titleSpan = document.createElement('span');
    titleSpan.innerHTML = `<strong>Grid: ${note.gridId}</strong>`;
    Object.assign(titleSpan.style, { fontSize: '15px', color: '#f57f17', lineHeight: '1' });
    
    const buttonGroup = document.createElement('div');
    Object.assign(buttonGroup.style, { display: 'flex', gap: '5px', alignItems: 'center' });
    
    const hlBtn = document.createElement('button');
    hlBtn.innerText = 'FIND';
    Object.assign(hlBtn.style, { cursor: 'pointer', background: 'rgba(0,0,0,0.05)', border: '1px solid rgba(0,0,0,0.1)', color: '#666', fontSize: '9px', fontWeight: 'bold', borderRadius: '3px', padding: '4px 5px', letterSpacing: '0.5px' });
    hlBtn.onclick = () => triggerHighlight(note.gridId);

    const closeBtn = document.createElement('button');
    closeBtn.innerText = '×';
    Object.assign(closeBtn.style, { cursor: 'pointer', background: 'rgba(0,0,0,0.05)', border: 'none', color: '#999', fontSize: '18px', fontWeight: 'bold', borderRadius: '4px', padding: '0 6px', lineHeight: '1' });
    closeBtn.onclick = () => { 
        dismissedRules.add('note-' + index); 
        alertBox.remove(); 
        clearHighlights(); 
        checkMinification(containerId);
    };
    
    buttonGroup.appendChild(hlBtn);
    buttonGroup.appendChild(closeBtn);
    
    headerRow.appendChild(titleSpan);
    headerRow.appendChild(buttonGroup);

    const bodyRow = document.createElement('div');
    let linksHtml = '';
    let count = 1;
    [note.link1, note.link2, note.link3].forEach(link => {
        if (link) {
            let safeLink = link.startsWith('http') ? link : 'https://' + link;
            linksHtml += `<a href="${safeLink}" target="_blank" style="color: #1565c0; text-decoration: underline; font-weight: bold; pointer-events: auto; display: inline-block; margin-right: 10px; margin-top: 5px; font-size: 13px;">[${count}]</a>`;
            count++;
        }
    });

    let formattedInfo = note.info ? note.info.replace(/\n/g, '<br>') : '';
    bodyRow.innerHTML = `
        <span style="font-size:15px; display:block; line-height:1.3; color: #000; overflow-wrap: break-word;">${formattedInfo}</span>
        ${linksHtml ? `<div style="margin-top: 5px; padding-top: 5px; border-top: 1px dashed #fbc02d;">${linksHtml}</div>` : ''}
    `;
    
    alertBox.appendChild(headerRow);
    alertBox.appendChild(bodyRow);
    
    listContainer.appendChild(alertBox);
    checkMinification(containerId);
}