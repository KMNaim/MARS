// ==========================================
// --- THEME INITIALIZATION & TOGGLE ---
// ==========================================
const themeToggleCheckbox = document.getElementById('themeToggleCheckbox');
if (themeToggleCheckbox) {
    const currentTheme = localStorage.getItem('marsTheme') || 'dark';
    
    if (currentTheme === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
        themeToggleCheckbox.checked = true;
    } else {
        document.documentElement.removeAttribute('data-theme');
        themeToggleCheckbox.checked = false;
    }
    
    themeToggleCheckbox.addEventListener('change', (e) => {
        if (e.target.checked) {
            document.documentElement.setAttribute('data-theme', 'dark');
            localStorage.setItem('marsTheme', 'dark');
        } else {
            document.documentElement.removeAttribute('data-theme');
            localStorage.setItem('marsTheme', 'light');
        }
    });
}

// ==========================================
// --- DASHBOARD LOGIC ---
// ==========================================
const container = document.getElementById('entries-container');
const notesContainer = document.getElementById('notes-container');

// --- RULE LOGIC ---
function createEntryPair(keyword = "", message = "", exception = "", color = "#b71c1c", fontSize = "14px", position = "bottom-left", active = true) {
    const div = document.createElement('div');
    div.className = 'entry-pair';
    div.style.borderLeftColor = color;
    div.style.transition = "opacity 0.3s";
    div.style.opacity = active ? "1" : "0.5";
    
    div.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; border-bottom: 1px solid var(--border-color); padding-bottom: 8px;">
            <label style="cursor: pointer; display: flex; align-items: center; gap: 8px; margin: 0;">
                <input type="checkbox" class="active-toggle" style="width: 18px; height: 18px; cursor: pointer; margin: 0;" ${active ? 'checked' : ''}>
                <span style="font-size: 15px; font-weight: bold; color: ${active ? 'var(--accent-green)' : 'var(--text-muted)'};" class="active-text">
                    Rule: ${active ? 'ON' : 'OFF'}
                </span>
            </label>
            <button class="remove-btn" style="position: static; font-size: 22px; line-height: 1; padding: 0 5px;">×</button>
        </div>
        <div class="row">
            <div><label>Trigger Keywords:</label><input type="text" class="keyword-input" placeholder="e.g. Look Forward"></div>
            <div><label>Exceptions:</label><input type="text" class="exception-input" placeholder="e.g. Approved"></div>
        </div>
        <label>Warning Message:</label><textarea class="message-input" rows="2"></textarea>
        <div class="row">
            <div><label>Box Color:</label>
                <select class="color-input">
                    <option value="#b71c1c" ${color === "#b71c1c" ? "selected" : ""}>Critical Red</option>
                    <option value="#ef6c00" ${color === "#ef6c00" ? "selected" : ""}>Warning Orange</option>
                    <option value="#2e7d32" ${color === "#2e7d32" ? "selected" : ""}>Success Green</option>
                    <option value="#1565c0" ${color === "#1565c0" ? "selected" : ""}>Info Blue</option>
                    <option value="#455a64" ${color === "#455a64" ? "selected" : ""}>Dark Grey</option>
                </select>
            </div>
            <div><label>Font Size:</label>
                <select class="font-input">
                    <option value="12px" ${fontSize === "12px" ? "selected" : ""}>Small</option>
                    <option value="14px" ${fontSize === "14px" ? "selected" : ""}>Medium</option>
                    <option value="18px" ${fontSize === "18px" ? "selected" : ""}>Large</option>
                    <option value="22px" ${fontSize === "22px" ? "selected" : ""}>X-Large</option>
                </select>
            </div>
        </div>
        <label>Box Position:</label>
        <select class="position-input">
            <option value="top-left" ${position === "top-left" ? "selected" : ""}>Top Left</option>
            <option value="top-center" ${position === "top-center" ? "selected" : ""}>Top Center</option>
            <option value="top-right" ${position === "top-right" ? "selected" : ""}>Top Right</option>
            <option value="middle-left" ${position === "middle-left" ? "selected" : ""}>Middle Left</option>
            <option value="middle-center" ${position === "middle-center" ? "selected" : ""}>Middle Center</option>
            <option value="middle-right" ${position === "middle-right" ? "selected" : ""}>Middle Right</option>
            <option value="bottom-left" ${position === "bottom-left" ? "selected" : ""}>Bottom Left</option>
            <option value="bottom-center" ${position === "bottom-center" ? "selected" : ""}>Bottom Center</option>
            <option value="bottom-right" ${position === "bottom-right" ? "selected" : ""}>Bottom Right</option>
        </select>
    `;
    
    div.querySelector('.keyword-input').value = keyword || "";
    div.querySelector('.exception-input').value = exception || "";
    div.querySelector('.message-input').value = message || "";
    
    const toggle = div.querySelector('.active-toggle');
    const text = div.querySelector('.active-text');
    toggle.onchange = (e) => {
        const isChecked = e.target.checked;
        text.innerText = `Rule: ${isChecked ? 'ON' : 'OFF'}`;
        text.style.color = isChecked ? 'var(--accent-green)' : 'var(--text-muted)';
        div.style.opacity = isChecked ? '1' : '0.5';
    };
    
    div.querySelector('.color-input').onchange = (e) => div.style.borderLeftColor = e.target.value;
    div.querySelector('.remove-btn').onclick = () => div.remove();
    container.appendChild(div);
}

// --- NEW LIVE DUPLICATE SCANNER LOGIC ---
function updateDuplicateTracker() {
    const trackerBox = document.getElementById('duplicate-tracker');
    const trackerTitle = document.getElementById('tracker-title');
    const listElement = document.getElementById('duplicate-list');
    
    const gridIdTracker = {};
    const duplicateIds = new Set();

    const notePairs = Array.from(document.querySelectorAll('#notes-container .entry-pair'));

    notePairs.forEach(pair => {
        const rawInput = pair.querySelector('.grid-input').value.trim().toLowerCase();
        if (rawInput === "") return;
        
        const gIds = rawInput.split(',').map(id => id.trim()).filter(id => id.length > 0);
        gIds.forEach(gId => {
            if (!gridIdTracker[gId]) gridIdTracker[gId] = [];
            if (!gridIdTracker[gId].includes(pair)) {
                gridIdTracker[gId].push(pair);
            }
        });
    });

    for (const gId in gridIdTracker) {
        if (gridIdTracker[gId].length > 1) {
            duplicateIds.add(gId);
        }
    }

    if (duplicateIds.size > 0) {
        trackerBox.style.background = 'var(--btn-danger)';
        trackerBox.style.borderColor = 'var(--btn-danger)';
        trackerTitle.style.color = 'white';
        trackerTitle.innerText = `Duplicate Grid Scanner: ${duplicateIds.size} Found!`;
        
        listElement.innerHTML = Array.from(duplicateIds).map(id => `<li>${id.toUpperCase()}</li>`).join('');
        listElement.style.display = 'block';
        listElement.style.color = 'white';
    } else {
        trackerBox.style.background = 'var(--panel-bg)';
        trackerBox.style.borderColor = 'var(--accent-green)';
        trackerTitle.style.color = 'var(--accent-green)';
        trackerTitle.innerText = 'Duplicate Grid Scanner: All Clear';
        
        listElement.innerHTML = '';
        listElement.style.display = 'none';
    }
}

// --- RELATED INFO LOGIC ---
function createNotePair(gridId = "", info = "", link1 = "", link2 = "", link3 = "", timestamp = null) {
    const div = document.createElement('div');
    div.className = 'entry-pair';
    div.style.borderLeftColor = 'var(--sync-yellow-border)';
    div.style.backgroundColor = 'var(--sync-yellow-bg)';
    
    // Set Timestamp Data (Ensure it evaluates precisely to an integer)
    const activeTimestamp = timestamp ? parseInt(timestamp, 10) : Date.now();
    div.dataset.timestamp = activeTimestamp;
    
    // Convert to readable format using explicit 'en-US' locale to prevent character encoding bugs
    const readableDate = new Date(activeTimestamp).toLocaleString('en-US', {
        year: 'numeric', month: 'numeric', day: 'numeric',
        hour: 'numeric', minute: '2-digit', second: '2-digit', hour12: true
    });
    
    // Check if older than 180 days
    const isBackdated = (Date.now() - activeTimestamp) > (180 * 24 * 60 * 60 * 1000);
    
    div.innerHTML = `
        <span class="last-updated-text" style="position: absolute; top: 15px; right: 40px; font-size: 11px; color: var(--text-muted); font-style: italic;">Date Added: ${readableDate}</span>
        <button class="remove-btn" style="position: absolute; top: 10px; right: 10px; cursor: pointer; border: none; background: none; font-size: 20px;">×</button>
        <div style="margin-top: 5px;">
            <label style="color: var(--accent-yellow); display: flex; align-items: center;">
                1. Grid ID / Identifier:
                <span class="backdated-badge" style="display: ${isBackdated ? 'inline-block' : 'none'}; background: var(--btn-danger); color: white; padding: 2px 6px; border-radius: 4px; font-size: 10px; margin-left: 10px; letter-spacing: 0.5px;">⚠️ BACKDATED (>180 DAYS)</span>
            </label>
            <input type="text" class="grid-input" placeholder="e.g. 283407361, 99283742">
            
            <label style="color: var(--accent-yellow);">2. Grid Info:</label>
            <textarea class="info-input" rows="3" placeholder="e.g. False positive due to middle name"></textarea>
            
            <button class="toggle-sources-btn" style="margin-top: 10px; background: none; border: none; color: var(--btn-primary); cursor: pointer; padding: 0; font-size: 13px; font-weight: bold; text-decoration: underline;">+ Add / View Sources</button>
            
            <div class="sources-container" style="display: none; margin-top: 10px; padding: 10px; background: rgba(0,0,0,0.03); border-radius: 4px; border-left: 3px solid var(--accent-yellow);">
                <label style="color: var(--accent-yellow); margin-top: 0;">Source Link 1:</label>
                <input type="text" class="link1-input" placeholder="e.g. https://google.com">
                <label style="color: var(--accent-yellow);">Source Link 2:</label>
                <input type="text" class="link2-input" placeholder="Optional...">
                <label style="color: var(--accent-yellow);">Source Link 3:</label>
                <input type="text" class="link3-input" placeholder="Optional...">
            </div>
        </div>
    `;
    
    const gridInput = div.querySelector('.grid-input');
    gridInput.value = gridId || "";
    gridInput.addEventListener('input', updateDuplicateTracker);

    div.querySelector('.info-input').value = info || "";
    div.querySelector('.link1-input').value = link1 || "";
    div.querySelector('.link2-input').value = link2 || "";
    div.querySelector('.link3-input').value = link3 || "";
    
    const toggleBtn = div.querySelector('.toggle-sources-btn');
    const sourcesContainer = div.querySelector('.sources-container');
    toggleBtn.onclick = (e) => {
        e.preventDefault();
        if (sourcesContainer.style.display === 'none') {
            sourcesContainer.style.display = 'block';
            toggleBtn.innerText = '- Hide Sources';
        } else {
            sourcesContainer.style.display = 'none';
            toggleBtn.innerText = '+ Add / View Sources';
        }
    };
    
    if (link1 || link2 || link3) {
        sourcesContainer.style.display = 'block';
        toggleBtn.innerText = '- Hide Sources';
    }

    div.querySelector('.remove-btn').onclick = () => {
        div.remove();
        updateDuplicateTracker();
    };
    
    notesContainer.appendChild(div);
}

// --- LOAD DATA & GLOBAL SETTINGS ---
chrome.storage.local.get(['rules', 'notes', 'autoSyncRulesEnabled', 'autoSyncNotesEnabled', 'githubToken'], (data) => {
    
    if (data.githubToken) {
        document.getElementById('github-token').value = data.githubToken;
    }

    const autoSyncRulesCheckbox = document.getElementById('auto-sync-rules-toggle');
    if(autoSyncRulesCheckbox) {
        autoSyncRulesCheckbox.checked = data.autoSyncRulesEnabled !== false;
        autoSyncRulesCheckbox.addEventListener('change', (e) => {
            chrome.storage.local.set({ autoSyncRulesEnabled: e.target.checked });
        });
    }

    const autoSyncNotesCheckbox = document.getElementById('auto-sync-notes-toggle');
    if(autoSyncNotesCheckbox) {
        autoSyncNotesCheckbox.checked = data.autoSyncNotesEnabled !== false;
        autoSyncNotesCheckbox.addEventListener('change', (e) => {
            chrome.storage.local.set({ autoSyncNotesEnabled: e.target.checked });
        });
    }

    if (data.rules && data.rules.length > 0) {
        const uniqueRules = [];
        const seen = new Set();
        data.rules.forEach(r => {
            if (!r) return;
            const identifier = (r.keyword || "").trim() + '|' + (r.message || "").trim();
            if (!seen.has(identifier)) { seen.add(identifier); uniqueRules.push(r); }
        });
        uniqueRules.forEach(r => createEntryPair(r.keyword, r.message, r.exception || "", r.color, r.fontSize, r.position, r.active !== false));
    } else {
        createEntryPair("", "", "", "#b71c1c", "14px", "bottom-left", true);
    }

    if (data.notes && data.notes.length > 0) {
        const uniqueNotes = [];
        const seen = new Set();
        let missingTimestampsFound = false;

        data.notes.forEach(n => {
            if (!n) return;
            const identifier = (n.gridId || "").trim() + '|' + (n.info || "").trim();
            if (!seen.has(identifier)) { 
                seen.add(identifier); 
                
                // NEW: If a note lacks a timestamp (from GitHub sync or old data), 
                // assign one instantly and flag it to be permanently saved.
                if (!n.timestamp) {
                    n.timestamp = Date.now();
                    missingTimestampsFound = true;
                } else {
                    n.timestamp = parseInt(n.timestamp, 10);
                }
                
                uniqueNotes.push(n); 
            }
        });
        
        // NEW: Lock in the permanent timestamps immediately if any were missing
        if (missingTimestampsFound) {
            chrome.storage.local.set({ notes: uniqueNotes });
        }
        
        // Sort the notes array by timestamp (oldest first)
        uniqueNotes.sort((a, b) => a.timestamp - b.timestamp);

        uniqueNotes.forEach(n => {
            let l1 = n.link1 !== undefined ? n.link1 : (n.link || "");
            createNotePair(n.gridId || "", n.info || "", l1, n.link2 || "", n.link3 || "", n.timestamp);
        });
    } else {
        createNotePair();
    }
    
    setTimeout(updateDuplicateTracker, 100);
});

// ==========================================
// --- MULTI-BUTTON EVENT BINDINGS ---
// ==========================================

// Add Buttons
document.querySelectorAll('.add-rule-btn').forEach(btn => btn.onclick = () => createEntryPair());
document.querySelectorAll('.add-note-btn').forEach(btn => btn.onclick = () => createNotePair());

// Save Token
document.getElementById('save-token').onclick = () => {
    const token = document.getElementById('github-token').value.trim();
    chrome.storage.local.set({ githubToken: token }, () => alert('GitHub Token Saved!'));
};

// Save Rules
document.querySelectorAll('.save-all-btn').forEach(btn => btn.onclick = () => {
    const rules = Array.from(document.querySelectorAll('#entries-container .entry-pair')).map(pair => ({
        keyword: pair.querySelector('.keyword-input').value.trim(),
        exception: pair.querySelector('.exception-input').value.trim(),
        message: pair.querySelector('.message-input').value.trim(),
        color: pair.querySelector('.color-input').value,
        fontSize: pair.querySelector('.font-input').value,
        position: pair.querySelector('.position-input').value,
        active: pair.querySelector('.active-toggle').checked
    }));
    chrome.storage.local.set({ rules }, () => alert('Rules Saved Locally!'));
});

// UPGRADED NOTES SAVE BUTTON (Includes Timestamp Logic)
document.querySelectorAll('.save-notes-btn').forEach(btn => btn.onclick = () => {
    let emptyFound = false;
    let duplicatesFound = false;
    const gridIdTracker = {}; 

    const notePairs = Array.from(document.querySelectorAll('#notes-container .entry-pair'));

    notePairs.forEach(pair => {
        pair.style.borderLeftColor = 'var(--sync-yellow-border)';
        pair.style.backgroundColor = 'var(--sync-yellow-bg)';
        
        const rawInput = pair.querySelector('.grid-input').value.trim().toLowerCase(); 
        
        if (rawInput === "") {
            emptyFound = true;
        } else {
            const gIds = rawInput.split(',').map(id => id.trim()).filter(id => id.length > 0);
            gIds.forEach(gId => {
                if (!gridIdTracker[gId]) gridIdTracker[gId] = [];
                if (!gridIdTracker[gId].includes(pair)) {
                    gridIdTracker[gId].push(pair);
                }
            });
        }
    });

    for (const gId in gridIdTracker) {
        if (gridIdTracker[gId].length > 1) {
            duplicatesFound = true;
            gridIdTracker[gId].forEach(pair => {
                pair.style.borderLeftColor = 'var(--btn-danger)'; 
                pair.style.backgroundColor = 'rgba(211, 47, 47, 0.1)'; 
            });
        }
    }

    if (duplicatesFound) {
        alert("Save Cancelled: Duplicate Grid IDs found!\n\nThe conflicting entries have been highlighted. Please delete or merge them before saving.");
        return; 
    }

    const notes = notePairs.map(pair => {
        return {
            gridId: pair.querySelector('.grid-input').value.trim(),
            info: pair.querySelector('.info-input').value.trim(),
            link1: pair.querySelector('.link1-input').value.trim(),
            link2: pair.querySelector('.link2-input').value.trim(),
            link3: pair.querySelector('.link3-input').value.trim(),
            timestamp: pair.dataset.timestamp ? parseInt(pair.dataset.timestamp, 10) : Date.now() // Save the internal tracking date
        };
    }).filter(n => n.gridId !== ""); 
    
    chrome.storage.local.set({ notes }, () => {
        if (emptyFound && notes.length === 0) alert('Please enter a Grid ID before saving!');
        else alert('Related Info Saved Locally!');
    });
});

// Clear Backdated Data Action
document.querySelectorAll('.clear-backdated-btn').forEach(btn => btn.onclick = () => {
    const now = Date.now();
    const cutoffMs = 180 * 24 * 60 * 60 * 1000;
    let removedCount = 0;
    
    document.querySelectorAll('#notes-container .entry-pair').forEach(pair => {
        const ts = parseInt(pair.dataset.timestamp, 10);
        if (ts && (now - ts) > cutoffMs) {
            pair.remove();
            removedCount++;
        }
    });
    
    if (removedCount > 0) {
        updateDuplicateTracker();
        alert(`Removed ${removedCount} backdated grid(s)!\n\nPlease click "Save Notes Locally" to permanently apply these changes.`);
    } else {
        alert("No backdated grids found! Everything is up to date.");
    }
});

// ==========================================
// --- CLOUD SYNC LOGIC (PULLING & PUSHING) ---
// ==========================================

function mergeAndSaveRules(newRules, successMessage) {
    chrome.storage.local.get(['rules'], (data) => {
        const existingRules = data.rules || [];
        const combinedRules = [...existingRules, ...newRules];
        const uniqueRules = [];
        const seen = new Set();
        combinedRules.forEach(r => {
            if (!r) return;
            const identifier = (r.keyword || "").trim() + '|' + (r.message || "").trim();
            if (!seen.has(identifier)) { seen.add(identifier); uniqueRules.push(r); }
        });
        chrome.storage.local.set({ rules: uniqueRules }, () => { alert(successMessage); location.reload(); });
    });
}

function mergeAndSaveNotes(newNotes, successMessage) {
    chrome.storage.local.get(['notes'], (data) => {
        const existingNotes = data.notes || [];
        const combinedNotes = [...existingNotes, ...newNotes];
        const uniqueNotes = [];
        const seen = new Set();
        combinedNotes.forEach(n => {
            if (!n || !n.gridId) return;
            const identifier = (n.gridId || "").trim() + '|' + (n.info || "").trim();
            if (!seen.has(identifier)) { seen.add(identifier); uniqueNotes.push(n); }
        });
        chrome.storage.local.set({ notes: uniqueNotes }, () => { alert(successMessage); location.reload(); });
    });
}

document.getElementById('force-sync').onclick = async () => {
    const url = "https://raw.githubusercontent.com/sabbirrahmanleon/MARS-Notifier-Database/main/alert_rules.json";
    const syncBtn = document.getElementById('force-sync');
    syncBtn.innerText = "Pulling...";
    try {
        const response = await fetch(url, { cache: "no-store" });
        const cloudRules = await response.json();
        const unlockedRules = cloudRules.map(r => ({ ...r, isTeam: false, active: true }));
        mergeAndSaveRules(unlockedRules, "Rules Pulled and Merged Successfully!");
    } catch (e) {
        alert("Sync Failed! Could not fetch the file from GitHub.");
        syncBtn.innerText = "Pull from Cloud";
    }
};

document.getElementById('force-sync-notes').onclick = async () => {
    const url = "https://raw.githubusercontent.com/sabbirrahmanleon/MARS-Notifier-Database/main/grid_info.json"; 
    const syncBtn = document.getElementById('force-sync-notes');
    syncBtn.innerText = "Pulling...";
    try {
        const response = await fetch(url, { cache: "no-store" });
        const cloudNotes = await response.json();
        mergeAndSaveNotes(cloudNotes, "Related Info Pulled and Merged Successfully!");
    } catch (e) {
        alert("Sync Failed! Could not fetch the file from GitHub.");
        syncBtn.innerText = "Pull from Cloud";
    }
};

async function pushDataToGitHub(url, dataObj, token, commitMessage, button) {
    const originalText = button.innerText;
    button.innerText = "Pushing...";
    try {
        if (!token) throw new Error("No GitHub Token provided. Please enter and save your token in the Admin panel.");
        let fileSha = "";
        const getRes = await fetch(url, { headers: { 'Authorization': `token ${token}` } });
        if (getRes.ok) {
            const getJson = await getRes.json();
            fileSha = getJson.sha;
        } else if (getRes.status !== 404) {
            throw new Error("Failed to authenticate with GitHub. Check your token permissions.");
        }
        const jsonString = JSON.stringify(dataObj, null, 4);
        const base64Content = btoa(unescape(encodeURIComponent(jsonString)));
        const payload = { message: commitMessage, content: base64Content, branch: "main" };
        if (fileSha) payload.sha = fileSha;

        const putRes = await fetch(url, {
            method: 'PUT',
            headers: { 'Authorization': `token ${token}`, 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!putRes.ok) {
            const errText = await putRes.text();
            throw new Error(`GitHub API Error: ${errText}`);
        }
        alert("Successfully pushed to GitHub!");
        button.innerText = originalText;
    } catch (e) {
        alert("PUSH FAILED:\n\n" + e.message);
        button.innerText = originalText;
    }
}

document.querySelectorAll('.push-rules-btn').forEach(btn => btn.onclick = (e) => {
    chrome.storage.local.get(['rules', 'githubToken'], (data) => {
        const token = data.githubToken;
        const rules = data.rules || [];
        const apiUrl = "https://api.github.com/repos/sabbirrahmanleon/MARS-Notifier-Database/contents/alert_rules.json";
        if(rules.length === 0 && !confirm("You have no rules locally. This will wipe the GitHub file. Continue?")) return;
        pushDataToGitHub(apiUrl, rules, token, "Admin Push: Updated Alert Rules", e.target);
    });
});

document.querySelectorAll('.push-notes-btn').forEach(btn => btn.onclick = (e) => {
    chrome.storage.local.get(['notes', 'githubToken'], (data) => {
        const token = data.githubToken;
        const notes = data.notes || [];
        const apiUrl = "https://api.github.com/repos/sabbirrahmanleon/MARS-Notifier-Database/contents/grid_info.json";
        if(notes.length === 0 && !confirm("You have no notes locally. This will wipe the GitHub file. Continue?")) return;
        pushDataToGitHub(apiUrl, notes, token, "Admin Push: Updated Grid Info", e.target);
    });
});

document.getElementById('clear-rules').onclick = () => {
    if (confirm("WARNING!\n\nAre you sure you want to delete EVERY single rule locally?")) {
        chrome.storage.local.set({ rules: [] }, () => { alert("All local rules cleared."); location.reload(); });
    }
};

document.querySelectorAll('.export-rules-btn').forEach(btn => btn.onclick = () => {
    chrome.storage.local.get(['rules'], (d) => { navigator.clipboard.writeText(JSON.stringify(d.rules || [])).then(() => alert("All rules copied!")); });
});

document.querySelectorAll('.import-rules-btn').forEach(btn => btn.onclick = () => {
    const val = prompt("Paste your exported rules (JSON text) here:");
    if (val) {
        try { mergeAndSaveRules(JSON.parse(val), "Rules Imported and Merged Successfully!"); } 
        catch (e) { alert("Invalid data format."); }
    }
});

document.getElementById('clear-notes').onclick = () => {
    if (confirm("WARNING!\n\nAre you sure you want to delete EVERY single piece of Related Info locally?")) {
        chrome.storage.local.set({ notes: [] }, () => { alert("All local info cleared."); location.reload(); });
    }
};

document.querySelectorAll('.export-notes-btn').forEach(btn => btn.onclick = () => {
    chrome.storage.local.get(['notes'], (d) => { navigator.clipboard.writeText(JSON.stringify(d.notes || [])).then(() => alert("All Related Info copied!")); });
});

document.querySelectorAll('.import-notes-btn').forEach(btn => btn.onclick = () => {
    const val = prompt("Paste your exported Related Info (JSON text) here:");
    if (val) {
        try { mergeAndSaveNotes(JSON.parse(val), "Related Info Imported and Merged Successfully!"); } 
        catch (e) { alert("Invalid data format."); }
    }
});